package DatabaseHandler;

public interface DatabaseSQLs {
	String shiftRegisterSQL = "INSERT INTO student_shifter (lastname, firstname, middlei, gender, typeofstudent, birthday, studentid"
	 		+ ", oldcourse, oldprogram, newcourse, newprogram) "
	 		+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	 String transferRegisterSQL = "INSERT INTO student_transfer (lastname, firstname, middlei, gender, typeofstudent, birthday, oldschool"
	 		+ ", oldcourse, oldprogram, newcourse, newprogram) "
	 		+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	 String loginsql = "SELECT userid, password, roles FROM users WHERE userid = ? AND password = ? "
				+ "UNION"
				+ " SELECT studentid, birthday, typeofstudent FROM student_shifter WHERE studentid = ? AND birthday = ?"
				+ "UNION"
				+ " SELECT id, birthday, typeofstudent FROM student_transfer WHERE id = ? AND birthday = ?";
	 
}
