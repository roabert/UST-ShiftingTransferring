package Model;

import java.sql.*;

import DatabaseHandler.DatabaseSQLs;


public class RegisterTransferDAO implements DatabaseSQLs {

	String lname, fname, mname, gender, bdate, type;

	 // for Transferees
	 String oldschool, transferoldcollege, transferoldprogram, transfernewcollege, transfernewprogram;
	 
	 public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBdate() {
		return bdate;
	}
	public void setBdate(String bdate) {
		this.bdate = bdate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getOldschool() {
		return oldschool;
	}
	public void setOldschool(String oldschool) {
		this.oldschool = oldschool;
	}
	public String getTransferoldcollege() {
		return transferoldcollege;
	}
	public void setTransferoldcollege(String transferoldcollege) {
		this.transferoldcollege = transferoldcollege;
	}
	public String getTransferoldprogram() {
		return transferoldprogram;
	}
	public void setTransferoldprogram(String transferoldprogram) {
		this.transferoldprogram = transferoldprogram;
	}
	public String getTransfernewcollege() {
		return transfernewcollege;
	}
	public void setTransfernewcollege(String transfernewcollege) {
		this.transfernewcollege = transfernewcollege;
	}
	public String getTransfernewprogram() {
		return transfernewprogram;
	}
	public void setTransfernewprogram(String transfernewprogram) {
		this.transfernewprogram = transfernewprogram;
	}
	
	public void RegisterProcessTransfer(Connection conn) {
		 try{
				
					   PreparedStatement ps = conn.prepareStatement(transferRegisterSQL);
						 ps.setString(1, lname);
						 ps.setString(2, fname);
						 ps.setString(3, mname);
						 ps.setString(4, gender);
						 ps.setString(5, type);
						 ps.setString(6, bdate);
						 ps.setString(7, oldschool);
						 ps.setString(8, transferoldcollege);
						 ps.setString(9, transferoldprogram);
						 ps.setString(10, transfernewcollege);
						 ps.setString(11, transfernewprogram);
						
					     ps.executeUpdate();
					     
					    // request.setAttribute("sessionUser", generateID);
					  //   request.getRequestDispatcher("Student-Transferee/Transfer-Welcome.jsp")
					   //  .forward(request, response);
				   
			 }catch(SQLException sql) {
				 sql.printStackTrace();
			 }
	}
	
}
